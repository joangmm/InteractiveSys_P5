﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : MonoBehaviour
{
    private bool isNear=false;
    void Update()
    {

        if(this.transform.position.y >= 0.845)
        {
            isNear = true;
        }

        if (!isNear)
        {
            this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y + 0.006f, this.transform.position.z);
        }
    }
}
