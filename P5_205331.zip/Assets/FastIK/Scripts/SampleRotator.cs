﻿using UnityEngine;

namespace DitzelGames.FastIK
{
    public class SampleRotator : MonoBehaviour
    {
        public float speed = 90.0f;
        private float highspeed = 1500.0f;

        private Vector3 pos = new Vector3(-1.802f, 1.594f, 0.131f);
        public GameObject spark;
        private bool isPSinstantiated = false;

        void Start()
        {
            
        }
        void Update()
        {
            if(speed <= highspeed)
            {
                speed += 0.55f;
                transform.Rotate(0, Time.deltaTime * speed, 0);
            }
            else
            {
                speed += 0.01f;
                transform.Rotate(0, Time.deltaTime * speed, 0);
                if (!isPSinstantiated)
                {
                    Instantiate(spark, pos, Quaternion.identity);
                    isPSinstantiated = true;
                }
                
            }
            
        }
    }
}
